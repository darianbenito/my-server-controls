// Disclaimer and Copyright Information
// UpDownControl.cs : 
//
// All rights reserved.
//
// Written by Pardesi Services, LLC
// Version 1.00
//
// Distribute freely, except: don't remove our name from the source or
// documentation (don't take credit for my work), mark your changes (don't
// get me blamed for your possible bugs), don't alter or remove this
// notice.
// No warrantee of any kind, express or implied, is included with this
// software; use at your own risk, responsibility for damages (if any) to
// anyone resulting from the use of this software rests entirely with the
// user.
//
// Send bug reports, bug fixes, enhancements, requests, flames, etc. to
// softomatix@pardesiservices.com
///////////////////////////////////////////////////////////////////////////////
//

using System;
using System.Diagnostics;
using System.Text;						// Required for StringBuilder type
using System.Web;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;			// Required for Designer attribute
using System.Collections;				// Required for NameValueCollection
using System.Collections.Specialized;	// Required for NameValueCollection

namespace ASPNet_Controls
{
	// The UpDown Arrows Position enumeration.
	public enum ArrowsPosition 
	{
		Left = 0,
		Right = 1,
	}

	/// <summary>
	/// 
	/// </summary>
	/// 
	[ToolboxData("<{0}:UpDownControl Runat=server>/>")]
	[Designer(typeof(UpDownControl))]
	public class UpDownControl : WebControl, IPostBackDataHandler
	{
		private string m_strValue = "";
		protected string m_strUpArrowImg = "";
		protected string m_strDownArrowImg = "";
		protected ArrowsPosition m_enumArrowsPosition = ArrowsPosition.Right;
		protected int m_iArrowsSpacing = 2;
		protected int m_iMaxValue = 100;
		protected int m_iMinValue = 0;
		protected int m_iIncrement = 1;

		/// <summary>
		/// Event handler for change value event.
		/// </summary>
		public event EventHandler ValueChanged;

		/// <summary>
		/// Control constructor.
		/// </summary>
		public UpDownControl()
		{
		}

		/// <summary>
		/// Property for setting and getting the value stored in the control.
		/// </summary>
		public string Text
		{
			get
			{
				object obj = ViewState["Text"];
				m_strValue = (obj == null) ? String.Empty : (string)obj;
				return m_strValue;
			}

			set
			{
				m_strValue = value;
				ViewState["Text"] = value;
			}
		}

		/// <summary>
		/// Property for specifying the URL for up-arrow image.
		/// </summary>
		[Category("Text")]
		[Description("URL for up arrow image")]
		public string UpArrowImgUrl
		{
			get
			{
				return this.m_strUpArrowImg;
			}
			set
			{
				this.m_strUpArrowImg = value;
			}
		}

		/// <summary>
		/// Property for specifying the URL for down arrow image.
		/// </summary>
		[Category("Text")]
		[Description("URL for down arrow image")]
		public string DownArrowImgUrl
		{
			get
			{
				return this.m_strDownArrowImg;
			}
			set
			{
				this.m_strDownArrowImg = value;
			}
		}

		/// <summary>
		/// Propert for specifying the side on which the arrows should be placed. It
		/// acepts two values "Left" and "Right"
		/// </summary>
		[Category("Appearance")]
		[Description("Specify if up-down arows will be displayed on right side or not.")]
		public ArrowsPosition ArrowsPositionSide
		{
			get
			{
				return this.m_enumArrowsPosition;
			}
			set
			{
				this.m_enumArrowsPosition = value;
			}
		}

		/// <summary>
		/// Property for specifying the spacing between text control and arrows.
		/// </summary>
		[Category("Appearance")]
		[Description("Specify the spacing between text-box and up-down arrows.")]
		public int ArrowsSpacing
		{
			get
			{
				return this.m_iArrowsSpacing;
			}
			set
			{
				this.m_iArrowsSpacing = value;
			}
		}

		/// <summary>
		/// Property for specifying  MAX value for up-down control.
		/// </summary>
		[Category("Action")]
		[Description("Specify the maximum value for control to display.")]
		public int MaxValue
		{
			get
			{
				return this.m_iMaxValue;
			}
			set
			{
				this.m_iMaxValue = value;
			}
		}

		/// <summary>
		/// Property for specifying the MIN value for up-down control.
		/// </summary>
		[Category("Action")]
		[Description("Specify the minimum value for control to display.")]
		public int MinValue
		{
			get
			{
				return this.m_iMinValue;
			}
			set
			{
				this.m_iMinValue = value;
			}
		}

		/// <summary>
		/// Property for specifying increment for up-down control.
		/// </summary>
		[Category("Action")]
		[Description("Specify the increment value for up-down.")]
		public int Increment
		{
			get
			{
				return this.m_iIncrement;
			}
			set
			{
				this.m_iIncrement = value;
			}
		}

		/// <summary>
		/// This property returns the uniue name that is assigned ot the hidden
		/// field for storing control's value.
		/// </summary>
		protected string HiddenID
		{
			get
			{
				return "__" + ClientID + "_State";
			}
		}

		/// <summary>
		/// This field returns the name of the variable that saves the reference to
		/// hidden field DHTML object storing the value of control.
		/// </summary>
		protected string HiddenFieldVar
		{
			get
			{
				return "ob_" + HiddenID;
			}
		}

		/// <summary>
		/// This property returns the unique name that is assigned to the text
		/// control.
		/// </summary>
		protected string InputCtlName
		{
			get
			{
				return "__" + this.ClientID + "_Input";
			}
		}

		/// <summary>
		/// This property returns the name of the variable that holds the reference to 
		/// the  text control DHTML object.
		/// </summary>
		protected string InputCtlVarName
		{
			get
			{
				return "ob" + this.ClientID;
			}
		}

		/// <summary>
		/// This property returns the name of tje vartiables that is used to store the
		/// value of the control in client side script.
		/// </summary>
		protected string InputCtlVarValue
		{
			get
			{
				return "i" + this.InputCtlVarName + "Val";
			}
		}

		/// <summary>
		/// This property returns the name of the function that is used to parse the
		/// text value of control into "int"
		/// </summary>
		protected string InputCtlValParseFunctionName
		{
			get
			{
				return "getControlValue_" + this.ClientID;
			}
		}

		/// <summary>
		/// This property returns the name of the function that handles when user clicks 
		/// on the up arrow image.
		/// </summary>
		protected string UpArrowClickFunction
		{
			get
			{
				return "onUpArrowClick_" + this.ClientID;
			}
		}

		/// <summary>
		/// This property returns the name of the function that handles when user clicks 
		/// on the down arrow image.
		/// </summary>
		protected string DownArrowClickFunction
		{
			get
			{
				return "onDownArrowClick_" + this.ClientID;
			}
		}

		/// <summary>
		/// This property returns the name of the variable for storing MAX value for the
		/// control, in client side script.
		/// </summary>
		protected string MaxValVar
		{
			get
			{
				return this.UniqueID + "_MaxVal";
			}
		}

		/// <summary>
		/// This property returns the name of the variable for storing MIN value for the
		/// control, in client side script.
		/// </summary>
		protected string MinValVar
		{
			get
			{
				return this.UniqueID + "_MinVal";
			}
		}

		/// <summary>
		/// The proprty return variable name for storing increment value for the control in
		/// client side script.
		/// </summary>
		protected string IncrementVar
		{
			get
			{
				return this.UniqueID + "_IncVal";
			}
		}

		/// <summary>
		/// This event is raised by framework to give chance to the controls to any intialization.
		/// At this stage, control should not make any assumption about existence of any other
		/// control on the container page. In this event, control should perfom any initialization
		/// that is not dependant on other controls or state.
		/// This control, registers itself with the page letting it know that it wants to be
		/// notified of PostBack event.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnInit(EventArgs e)
		{
			base.OnInit(e);

			if (Page != null)
			{
				Page.RegisterRequiresPostBack(this);
			}
		}

		/// <summary>
		/// This event is raised by framework just before the control is to be renders.
		/// Control takes this oppurtunity to register the hidden field that will be used
		/// to convey its value when postback happens.
		/// </summary>
		/// <param name="args"></param>
		protected override void OnPreRender(EventArgs args)
		{
			base.OnPreRender(args);
			if (Page != null)
			{
				Page.RegisterHiddenField(HiddenID, Text);
			}
		}

		/// <summary>
		/// This is the function that does the rendering of the control. It is called by 
		/// framework to give chance to the control to emi its HTML tags. Based on the
		/// properties set by the yser at design or run time, the control renders itself
		/// accordingly. For example, based on the side choses by user, the up-down images
		/// are placed are placed either on left or right.
		/// </summary>
		/// <param name="output"></param>
		protected override void Render(HtmlTextWriter output)
		{
			// Make sure that we have valid Up/Down image Urls.
			if (this.m_strDownArrowImg.Length == 0)
			{
				RenderErrorMessage("No image url provided for down arrow image.", output);
				return;
			}

			if (this.m_strUpArrowImg.Length == 0)
			{
				RenderErrorMessage("No image url provided for up arrow image.", output);
				return;
			}

			// Start rendering the control.
			StringBuilder strRender = new StringBuilder();
			strRender.Append("<table name=\"");					// Open <table>
			strRender.Append(this.UniqueID + "\"");
			strRender.Append(" id =\"" + this.UniqueID + "\"");
			if (this.Width.Value > 0)
			{
				strRender.Append(" width=\"");				
				strRender.Append(this.Width + "\"");
			}
			if (this.Height.Value > 0)
			{
				strRender.Append(" height=\"" + this.Height + "\"");
			}
			strRender.Append(" cellspacing=\"" + this.ArrowsSpacing + "px\"" + " cellpadding=\"0px\"");
			strRender.Append(">");

			strRender.Append("\n<tr>");						// Open <tr>
			strRender.Append("\n<td>");						// Open <td> first cell

			// Add actual rendering of <span> and image tags here.
			if (this.m_enumArrowsPosition == ArrowsPosition.Right)
			{
				AddTextSpanSection(strRender);
			}
			else
			{
				this.AddImageSection(strRender);
			}

			strRender.Append("\n</td>");						// Close <td> first cell

			strRender.Append("\n<td>");						// Open <td> second cell

			if (this.m_enumArrowsPosition == ArrowsPosition.Right)
			{
				this.AddImageSection(strRender);
			}
			else
			{
				AddTextSpanSection(strRender);
			}

			strRender.Append("\n</td>");						// Close <td> second cell
			strRender.Append("\n</tr>");						// Close <tr>
			strRender.Append("</table>");						// Close <table>

			RenderClientSideScript(strRender);

			output.Write(strRender.ToString());
		}

		/// <summary>
		/// Function emits the text-box control HTML tags.
		/// </summary>
		/// <param name="strRender"></param>
		private void AddTextSpanSection(StringBuilder strRender)
		{
			strRender.Append("\n<table cellspacing=\"0px\" cellpadding=\"0px\" height=\"" + this.Height + "\" >");
			// Add up arrow row
			strRender.Append("\n<tr>");
			strRender.Append("\n<td valign=\"center\">");
			strRender.Append("<input type=\"text\" style=\"height:" + this.Height+ ";\" ");
			strRender.Append(" value=\"");
			strRender.Append(this.Text);
			strRender.Append("\"");
			strRender.Append(" id=\"" + this.InputCtlName + "\"");
			strRender.Append(" name=\"" + this.InputCtlName + "\"");
			strRender.Append(">");
			strRender.Append("\n</td>");
			strRender.Append("\n</tr>");
			strRender.Append("</table>");
		}

		/// <summary>
		/// This function emits HTML tages for placing the up-down arraow images.
		/// </summary>
		/// <param name="strRender"></param>
		private void AddImageSection(StringBuilder strRender)
		{
			strRender.Append("\n<table cellspacing=\"0px\" cellpadding=\"0px\"");
			strRender.Append(" height=\"");
			strRender.Append(this.Height + "\">");
			// Add up arrow row
			strRender.Append("\n<tr>");
			strRender.Append("\n<td valign=\"bottom\">");
			strRender.Append("<img border=0 title=\"Increment value\" src=\"");
			strRender.Append(this.m_strUpArrowImg);
			strRender.Append("\"");
			strRender.Append(" onclick=\"javascript:" + this.UpArrowClickFunction + "();");
			strRender.Append("\">");
			strRender.Append("\n</td>");
			strRender.Append("\n</tr>");

			// Add down arrow row.
			strRender.Append("\n<tr>");
			strRender.Append("\n<td valign=\"top\">");
			strRender.Append("<img border=0 title=\"Decrement value\" src=\"");
			strRender.Append(this.m_strDownArrowImg);
			strRender.Append("\"");
			strRender.Append(" onclick=\"javascript:" + this.DownArrowClickFunction + "();");
			strRender.Append("\">");
			strRender.Append("\n</td>");
			strRender.Append("\n</tr>");

			strRender.Append("</table>");
		}

		/// <summary>
		/// This function renders the client side script for the control. This script
		/// emits the functions handling event for click on up-down images. In response
		/// to the click event, the functions change the values in the control's text
		/// box accordingly.
		/// </summary>
		/// <param name="strRender"></param>
		protected void RenderClientSideScript(StringBuilder strRender)
		{
			strRender.Append("\n");
			strRender.Append(
				"<script language=\"javascript\">" +
				"\n	var " + this.InputCtlVarName  + "= getDOMObject(\"" + this.InputCtlName + "\");" +
				"\n	var " + this.HiddenFieldVar + "= getDOMObject(\"" + this.HiddenID + "\");" +
				"\n var " + this.MaxValVar + " = " + this.MaxValue + ";" +
				"\n var " + this.MinValVar + " = " + this.MinValue + ";" +
				"\n var " + this.IncrementVar + " = " + this.Increment + ";" +
				"\n var " + this.InputCtlVarValue + "=" + this.InputCtlVarName + ".value;" +
				"\nfunction " + this.UpArrowClickFunction + "()" +
				"\n{" +
				"\nif (" + this.InputCtlVarValue + "< " + this.MaxValVar + ")" +
				"\n{" +
				"\n" + this.InputCtlVarName + ".value = ++" + this.InputCtlVarValue + ";" +
				"\n" + this.HiddenFieldVar + ".value = " + this.InputCtlVarName + ".value;" +
				"\n}" +
				"\n}" +
				"\nfunction "+ this.DownArrowClickFunction + "()" +
				"\n{" +
				"\nif ("  + this.InputCtlVarValue + " > " + this.MinValVar + ")" +
				"\n{" +
				"\n" + this.InputCtlVarName + ".value = --" + this.InputCtlVarValue + ";" +
				"\n" + this.HiddenFieldVar + ".value = " + this.InputCtlVarName + ".value;" +
				"\n}" +
				"\n}" +
				"\nfunction " + this.InputCtlValParseFunctionName + "(strVal)" +
				"\n{" +
				"\n var iVal = " + this.InputCtlName + ".value;" +
				"\nreturn parseInt(iVal, 10);" +
				"\n}" +
				"\n</script>");
		}

		/// <summary>
		/// Utility function to display error messages on the client's browser.
		/// </summary>
		/// <param name="strMessage"></param>
		/// <param name="output"></param>
		protected void RenderErrorMessage(string strMessage, HtmlTextWriter output)
		{
			// Out put the error message as a div tag.
			output.AddAttribute(HtmlTextWriterAttribute.Align, "center");
			output.AddStyleAttribute(HtmlTextWriterStyle.Color, "red");
			output.AddStyleAttribute(HtmlTextWriterStyle.FontWeight, "bold");
			output.RenderBeginTag(HtmlTextWriterTag.Div);
			output.Write(strMessage);
			output.RenderEndTag();
		}

		/// <summary>
		/// Framework will call this method when postback event is fired on the containing
		/// page. This gives a chance to the control to see if the data was changed for it
		/// or not. Based on this check, the control can decide to fire its own event, letting
		/// any other control know about its new state.
		/// </summary>
		/// <param name="postDataKey">Key identifying this control</param>
		/// <param name="postCollection">Collection containing the posted data</param>
		/// <returns></returns>
		bool IPostBackDataHandler.LoadPostData(string postDataKey, NameValueCollection postCollection)
		{
			string presentValue = this.Text;
			string postedValue = postCollection[HiddenID];

			// If two values don't match, then update the value.
			if (!presentValue.Equals(postedValue))
			{
				this.Text = postedValue;
				// Indicate the state of this control has changed.
				return true;
			}

			// If there was no change in the data, then indicate that there is
			// no change in state by returning false.
			return false;
		}

		/// <summary>
		/// This method gets called if server returns "true" from LoadPostData event indicating that
		/// control's state has changed. The control this oppurtunity to raise it own events.
		/// </summary>
		void IPostBackDataHandler.RaisePostDataChangedEvent()
		{
			OnValueChanged(EventArgs.Empty);
		}

		/// <summary>
		/// Event handler for the changed value of the control.
		/// </summary>
		/// <param name="args"></param>
		void OnValueChanged(EventArgs args)
		{
			// If the value has been changed, raise the event.
			if (ValueChanged != null)
			{
				ValueChanged(this, args);
			}
		}
	}
}
