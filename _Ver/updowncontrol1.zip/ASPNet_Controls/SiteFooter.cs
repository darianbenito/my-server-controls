using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNet_Controls
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class SiteFooter : UserControl
	{
		public SiteFooter()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
